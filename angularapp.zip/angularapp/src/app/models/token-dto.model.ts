export interface TokenDTO {
    token: string;
}