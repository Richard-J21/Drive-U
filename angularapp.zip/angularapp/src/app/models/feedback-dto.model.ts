export interface FeedbackDto {
    feedbackText?: string;
    userId?: number;
    driverId?: number;
    category?: string;
    rating?: number;
}
 